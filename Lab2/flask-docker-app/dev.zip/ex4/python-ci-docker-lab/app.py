def add(a, b):
    return a + b

# addition of 2 & 3
if __name__ == "__main__":
    print("Hello from Python CI Lab!")
    print("2 + 3 =", add(2, 3))